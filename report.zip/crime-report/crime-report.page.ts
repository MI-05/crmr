import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crime-report',
  templateUrl: './crime-report.page.html',
  styleUrls: ['./crime-report.page.scss'],
})
export class CrimeReportPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
