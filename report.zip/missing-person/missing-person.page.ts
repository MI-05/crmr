import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-missing-person',
  templateUrl: './missing-person.page.html',
  styleUrls: ['./missing-person.page.scss'],
})
export class MissingPersonPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
