import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MissingReportExPage } from './missing-report-ex.page';

const routes: Routes = [
  {
    path: '',
    component: MissingReportExPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MissingReportExPageRoutingModule {}
