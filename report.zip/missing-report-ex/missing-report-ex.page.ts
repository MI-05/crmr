import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'app-missing-report-ex',
  templateUrl: './missing-report-expage.html',
  styleUrls: ['./missing-report-expage.scss'],
})
export class MissingReportExPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
