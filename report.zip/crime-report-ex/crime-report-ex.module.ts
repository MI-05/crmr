import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CrimeReportExPageRoutingModule } from './crime-report-ex-routing.module';

import { CrimeReportExPage } from './crime-report-ex.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CrimeReportExPageRoutingModule
  ],
  declarations: [CrimeReportExPage]
})
export class CrimeReportExPageModule {}
