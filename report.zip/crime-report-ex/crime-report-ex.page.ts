import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crime-report-ex',
  templateUrl: './crime-report-ex.page.html',
  styleUrls: ['./crime-report-ex.page.scss'],
})
export class CrimeReportExPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
