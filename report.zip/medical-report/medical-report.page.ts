import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-medical-report',
  templateUrl: './medical-report.page.html',
  styleUrls: ['./medical-report.page.scss'],
})
export class MedicalReportPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
