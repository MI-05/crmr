import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-medical-info',
  templateUrl: './medical-info.page.html',
  styleUrls: ['./medical-info.page.scss'],
})
export class MedicalInfoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
